package main

import (
    "fmt"
    "math/rand"
    "sync"
    "time"
)

func main() {
}
