package main

import "fmt"
import "time"
import "unicode"

func main() {
	data := []rune{'a', 'b', 'c', 'd'}
}
