package msg

import "fmt"

func Exciting(msg string) {
	fmt.Printf("%v!\n", msg)
}
