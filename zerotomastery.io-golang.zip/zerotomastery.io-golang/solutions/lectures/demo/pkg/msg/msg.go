package msg

import "coursecontent/demo/pkg/display"

func Hi() {
	display.Display("Hi")
}
