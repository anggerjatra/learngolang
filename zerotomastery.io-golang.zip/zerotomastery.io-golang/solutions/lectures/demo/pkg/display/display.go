package display

import "fmt"

func Display(msg string) {
	fmt.Println(msg)
}
